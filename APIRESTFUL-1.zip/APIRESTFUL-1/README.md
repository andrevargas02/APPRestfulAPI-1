# Aplicação Web de Informações de Cidade

Este projeto é uma aplicação web que permite aos utilizadores pesquisar informações sobre cidades, incluindo descrições gerais, meteorologia, atrações turísticas e fotos. Utiliza um servidor Express para servir o conteúdo e obter dados de APIs externas.

## Funcionalidades

- **Informações da Cidade**: Introduza o nome de uma cidade para obter detalhes, incluindo uma descrição e uma imagem representativa.
- **Dados Meteorológicos**: Apresenta informações meteorológicas atuais para a cidade pesquisada.
- **Atrações Turísticas**: Lista atrações populares na cidade, com links para mais informações.
- **Fotos**: Mostra uma galeria de fotos da cidade.

## Estrutura do Projeto

- **index.html**: Página principal para pesquisar informações de cidades.
- **main.js**: Gera as interações do utilizador, pedidos API, e atualiza dinamicamente as informações da cidade na página principal.
- **styles.css**: Contém o estilo da aplicação.
- **tab1.html**: Exibe atrações turísticas da cidade.
- **tab1.js**: Obtém e exibe atrações turísticas na `tab1.html`.
- **tab2.html**: Mostra uma galeria de fotos da cidade.
- **tab2.js**: Obtém e exibe fotos na `tab2.html`.
- **server.js**: Configura o servidor Express e serve os endpoints API.
- **api.js**: Define e gere as rotas da API para obter informações de cidade, dados meteorológicos, atrações turísticas, e fotos.

## Instalação

1. Clone o repositório:
   ```bash
   git clone <repository-url>
   cd project-directory

2.Instale as dependências do projeto:

npm install

3. Crie um ficheiro .env no diretório raiz e adicione as chaves de API do OpenWeather e Unsplash.
4. Inicie o servidor:

npm start


