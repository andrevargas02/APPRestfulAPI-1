const express = require('express');
const router = express.Router();
const path = require('path');
const fetch = require('node-fetch');

router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

router.get('/tab1', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/tab1.html'));
});

router.get('/tab2', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/tab2.html'));
});

router.get('/api/wiki', async (req, res) => {
  const city = req.query.city;
  try {
    const response = await fetch(`https://pt.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(city)}`);
    if (!response.ok) {
      return res.status(404).json({ error: 'Cidade não encontrada.' });
    }
    const data = await response.json();
    res.json({
      title: data.title,
      description: data.extract,
      image: data.thumbnail ? data.thumbnail.source : null,
      pageUrl: data.content_urls ? data.content_urls.desktop.page : null,
    });
  } catch (error) {
    res.status(500).send('Erro ao obter definição da cidade.');
  }
});

router.get('/api/weather', async (req, res) => {
  const apiKey = process.env.OPENWEATHER_API_KEY;
  const city = encodeURIComponent(req.query.city);

  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=pt_br`
    );
    if (!response.ok) {
      return res.status(404).json({ error: 'Cidade não encontrada.' });
    }
    const data = await response.json();

    res.json({
      temperature: data.main.temp,
      weather: data.weather[0].description,
      humidity: data.main.humidity,
    });
  } catch (error) {
    res.status(500).send('Erro ao obter dados meteorológicos.');
  }
});

router.get('/api/attractions', async (req, res) => {
  const city = req.query.city;
  try {
    const cityResponse = await fetch(
      `https://pt.wikipedia.org/w/api.php?action=query&format=json&prop=coordinates&titles=${encodeURIComponent(
        city
      )}&formatversion=2&origin=*`
    );

    const cityData = await cityResponse.json();

    if (
      !cityData.query.pages ||
      cityData.query.pages.length === 0 ||
      !cityData.query.pages[0].coordinates
    ) {
      return res.status(404).send('Cidade não encontrada ou coordenadas indisponíveis.');
    }

    const coords = cityData.query.pages[0].coordinates[0];
    const lat = coords.lat;
    const lon = coords.lon;

    const attractionsResponse = await fetch(
      `https://pt.wikipedia.org/w/api.php?action=query&format=json&prop=coordinates|pageimages|pageterms|info&generator=geosearch&ggscoord=${lat}|${lon}&ggsradius=10000&ggslimit=10&inprop=url&pithumbsize=300&origin=*`
    );

    const attractionsData = await attractionsResponse.json();

    const attractions = [];
    for (const pageId in attractionsData.query.pages) {
      const page = attractionsData.query.pages[pageId];
      const title = page.title || 'Título indisponível';
      const url = page.fullurl || '';
      const description =
        page.terms && page.terms.description && page.terms.description.length > 0
          ? page.terms.description[0]
          : 'Sem descrição disponível';
      const image = page.thumbnail ? page.thumbnail.source : null;

      attractions.push({ title, url, description, image });
    }

    res.json({ attractions });
  } catch (error) {
    res.status(500).send('Erro ao obter atrações.');
  }
});

router.get('/api/photos', async (req, res) => {
  const city = req.query.city;
  const unsplashApiKey = process.env.UNSPLASH_API_KEY;

  try {
    const perPage = 12;
    const unsplashApiUrl = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(
      city
    )}&per_page=${perPage}&client_id=${unsplashApiKey}`;

    const unsplashResponse = await fetch(unsplashApiUrl);

    const data = await unsplashResponse.json();

    const photos = data.results.map((photo) => ({
      url: photo.urls.small,
      title: photo.alt_description || 'Photo',
    }));

    res.json({ photos });
  } catch (error) {
    res.status(500).send('Erro ao obter fotos da cidade.');
  }
});

module.exports = router;
