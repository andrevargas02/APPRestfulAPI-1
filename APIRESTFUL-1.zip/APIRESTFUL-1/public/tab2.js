document.addEventListener('DOMContentLoaded', async () => {
  const params = new URLSearchParams(window.location.search);
  const city = params.get('city');

  document.getElementById('city-name').textContent = city;
  await getCityPhotos(city);

  document.getElementById('back-button').addEventListener('click', () => {
    window.location.href = '/';
  });
});

async function getCityPhotos(city) {
  try {
    const response = await fetch(`/api/photos?city=${encodeURIComponent(city)}`);
    const data = await response.json();

    const photosContainer = document.getElementById('photos-container');
    photosContainer.innerHTML = '';

    data.photos.forEach((photo) => {
      const photoElement = document.createElement('div');
      photoElement.classList.add('photo-item');
      photoElement.innerHTML = `
        <img src="${photo.url}" alt="${photo.title || 'Foto da cidade'}" />
      `;
      photosContainer.appendChild(photoElement);
    });
  } catch (error) {
    alert('Erro ao obter fotos da cidade.');
  }
}
