document.addEventListener('DOMContentLoaded', async () => {
  const params = new URLSearchParams(window.location.search);
  const city = params.get('city');

  document.getElementById('city-name').textContent = city;
  await getAttractions(city);

  document.getElementById('back-button').addEventListener('click', () => {
    window.location.href = '/';
  });
});

async function getAttractions(city) {
  try {
    const response = await fetch(`/api/attractions?city=${encodeURIComponent(city)}`);
    const data = await response.json();

    const attractionsDiv = document.getElementById('attractions');
    attractionsDiv.innerHTML = '';

    data.attractions.forEach((attraction) => {
      const attractionElement = document.createElement('div');
      attractionElement.classList.add('attraction-item');
      attractionElement.innerHTML = `
        <h3>${attraction.title}</h3>
        ${attraction.image ? `<img src="${attraction.image}" alt="${attraction.title}" />` : ''}
        <p>${attraction.description}</p>
        <a href="${attraction.url}" target="_blank">Saiba mais</a>
      `;
      attractionsDiv.appendChild(attractionElement);
    });
  } catch (error) {
    alert('Erro ao obter atrações.');
  }
}
