document.getElementById('search-button').addEventListener('click', async () => {
  const city = document.getElementById('city-input').value.trim();

  document.getElementById('error-message').classList.add('hidden');
  document.getElementById('error-message').textContent = '';
  await getCityInfo(city);
});

async function getCityInfo(city) {
  try {
    const wikiResponse = await fetch(`/api/wiki?city=${encodeURIComponent(city)}`);
    if (!wikiResponse.ok) {
      throw new Error('Cidade não encontrada.');
    }
    const wikiData = await wikiResponse.json();

    const weatherResponse = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
    if (!weatherResponse.ok) {
      throw new Error('Cidade não encontrada ou erro ao obter dados meteorológicos.');
    }
    const weatherData = await weatherResponse.json();

    document.getElementById('city-name').textContent = wikiData.title;
    document.getElementById('city-definition').textContent = wikiData.description;

    const cityImage = document.getElementById('city-image');
    if (wikiData.image) {
      cityImage.src = wikiData.image;
      cityImage.classList.remove('hidden');
    } else {
      cityImage.classList.add('hidden');
    }

    const weatherDiv = document.getElementById('weather-data');
    weatherDiv.innerHTML = `
      <p>Temperatura: ${weatherData.temperature}°C</p>
      <p>Clima: ${weatherData.weather}</p>
      <p>Humidade: ${weatherData.humidity}%</p>
    `;

    document.getElementById('city-info').classList.remove('hidden');
    document.getElementById('what-to-do-button').classList.remove('hidden');
    document.getElementById('more-photos-button').classList.remove('hidden');

    document.getElementById('what-to-do-button').addEventListener('click', () => {
      window.location.href = '/tab1?city=' + encodeURIComponent(city);
    });

    document.getElementById('more-photos-button').addEventListener('click', () => {
      window.location.href = '/tab2?city=' + encodeURIComponent(city);
    });
  } catch (error) {

    document.getElementById('city-info').classList.add('hidden');
    const errorMessageDiv = document.getElementById('error-message');
    errorMessageDiv.textContent = 'Cidade inválida. Por favor, insira outra cidade.';
    errorMessageDiv.classList.remove('hidden');
  }
}
